# TenEats WordPress Theme

## Get Started

`npm install`

installs theme locally for production

### Development

`npm start`

### Production

Run `gulp compress` to create a zip folder to install on your WordPress site. Zip file is saved in the `bundled` folder.
