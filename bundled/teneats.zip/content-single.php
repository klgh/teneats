<div class="blog-post-single">
    <div class="blog-row">
        <div class="post-content">
            <div class="blog-post-top">
                <h2 class="blog-post-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>

                <p class="blog-post-meta"><?php the_date(); ?></p>
            </div>

            <div class="blog-content"><?php the_content(); ?></div>
        </div>
    </div>

</div><!-- /.blog-post -->
