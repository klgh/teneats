</div> <!-- /.container -->

<footer class="blog-footer">
    
</footer>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
<?php wp_footer(); ?>
</body>

</html>
