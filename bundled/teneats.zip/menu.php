<svg width="19" height="19" viewBox="0 0 19 19" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M0 2.8501H19V4.7501H0V2.8501ZM0 8.5501H19V10.4501H0V8.5501ZM0 14.2501H19V16.1501H0V14.2501Z" fill="white"/>
</svg>